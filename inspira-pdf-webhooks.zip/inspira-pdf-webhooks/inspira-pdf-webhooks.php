<?php
/**
 * Plugin Name: Webhooks de generación de PDF (Inspira)
 * Description: Fuente única de verdad para las URLs de los webhooks que generan los informes PDF de Inspira. Sustituye las URLs escritas a mano en el tema y en «Áreas Asignadas» por una configuración editable desde wp-admin, con envío de prueba contra datos reales.
 * Version:     1.0.0
 * Author:      WMS Latam
 * Text Domain: inspira-pdf-webhooks
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * POR QUÉ UN PLUGIN APARTE Y NO UN AJUSTE MÁS DENTRO DE «ÁREAS ASIGNADAS»
 * Los dos consumidores viven en sitios distintos del árbol: el botón
 * «Descargar resultado» de /resultado-test-personal-completo/ lo pinta el
 * tema hijo (assets/js/download-results.js) y los botones «Informe general»
 * los pinta el plugin Áreas Asignadas. Si la configuración viviera en
 * cualquiera de los dos, el otro tendría que depender de él. Viviendo
 * aparte, ambos leen del mismo sitio y ninguno depende del otro: si este
 * plugin se desactiva, cada consumidor cae a la URL que usaba antes y las
 * descargas siguen funcionando.
 *
 * @package InspiraPdfWebhooks
 */

defined( 'ABSPATH' ) || exit;

define( 'IPW_VERSION', '1.0.0' );
define( 'IPW_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'IPW_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'IPW_TEXT_DOMAIN', 'inspira-pdf-webhooks' );

require_once IPW_PLUGIN_DIR . 'includes/class-ipw-settings.php';
require_once IPW_PLUGIN_DIR . 'includes/class-ipw-data.php';
require_once IPW_PLUGIN_DIR . 'includes/class-ipw-tester.php';
require_once IPW_PLUGIN_DIR . 'includes/class-ipw-admin.php';

/**
 * API pública del plugin: la usan el tema y Áreas Asignadas para resolver
 * la URL de un webhook sin conocer cómo se almacena. Devuelve '' si el
 * identificador no existe, para que el llamador pueda decidir su respaldo.
 */
function ipw_get_webhook( string $slug ): string {
	return IPW_Settings::get_url( $slug );
}

function ipw_bootstrap(): void {
	( new IPW_Settings() )->register_hooks();
	( new IPW_Admin() )->register_hooks();
	( new IPW_Tester() )->register_hooks();

	// Publica las URLs configuradas en el front-end para que los scripts
	// ya existentes (download-results.js, areas-asignadas.js) las lean sin
	// tener que encolarse desde aquí ni cambiar sus dependencias.
	add_action( 'wp_head', 'ipw_print_front_config', 1 );
}
add_action( 'plugins_loaded', 'ipw_bootstrap' );

/**
 * Imprime window.ipwPdfWebhooks en el <head>, antes de cualquier script del
 * tema o de los plugins (que se encolan en el footer). Solo contiene URLs
 * de webhooks públicos, no secretos: los tokens de las integraciones
 * siguen viviendo en el servidor.
 */
function ipw_print_front_config(): void {
	if ( is_admin() ) {
		return;
	}

	$config = wp_json_encode( IPW_Settings::all_urls() );

	printf(
		"<script id=\"ipw-pdf-webhooks\">window.ipwPdfWebhooks=%s;</script>\n",
		$config ? $config : '{}'
	);
}
