/**
 * Pantalla «Webhooks de generación de PDF»: selectores en cascada y envío
 * de prueba.
 *
 * Sin jQuery a propósito: la pantalla no depende de nada más que del
 * objeto `ipwAdmin` que localiza class-ipw-admin.php. Cada tarjeta es
 * independiente, así que todo el estado (empresa/área/trabajador elegidos)
 * vive dentro de su propia tarjeta y no en variables compartidas.
 */
( function () {
	'use strict';

	var i18n = ( window.ipwAdmin && window.ipwAdmin.i18n ) || {};

	document.querySelectorAll( '.ipw-card' ).forEach( initCard );
	initModalExito();

	/* ───────────────────────────────────────────────────────────────────
	 * Modal de confirmación tras guardar
	 * ─────────────────────────────────────────────────────────────────── */

	/**
	 * El marcado lo imprime PHP solo cuando hay algo que confirmar, así
	 * que si el elemento existe es que hay que abrirlo.
	 */
	function initModalExito() {
		var modal = document.getElementById( 'ipw-modal-exito' );

		if ( ! modal ) {
			return;
		}

		var boton   = modal.querySelector( '.ipw-modal-cerrar' );
		var previo  = document.activeElement;
		var cerrado = false;

		function cerrar() {
			if ( cerrado ) {
				return;
			}

			cerrado = true;
			modal.classList.remove( 'is-open' );
			document.body.classList.remove( 'ipw-modal-abierto' );
			document.removeEventListener( 'keydown', alPulsarTecla );

			// Se espera a que termine la transición antes de sacarlo del
			// árbol, para que no desaparezca de golpe.
			window.setTimeout( function () {
				modal.remove();

				if ( previo && previo.focus ) {
					previo.focus();
				}
			}, 200 );
		}

		function alPulsarTecla( event ) {
			if ( 'Escape' === event.key || 'Esc' === event.key ) {
				cerrar();
				return;
			}

			// Mientras el modal está abierto es el único elemento
			// enfocable: el tabulador no debe llevar al formulario de
			// detrás, que en ese momento no es accionable.
			if ( 'Tab' === event.key ) {
				event.preventDefault();

				if ( boton ) {
					boton.focus();
				}
			}
		}

		if ( boton ) {
			boton.addEventListener( 'click', cerrar );
		}

		modal.addEventListener( 'click', function ( event ) {
			// Solo el fondo cierra; un clic dentro de la tarjeta, no.
			if ( event.target === modal ) {
				cerrar();
			}
		} );

		document.addEventListener( 'keydown', alPulsarTecla );

		// Se quita settings-updated de la URL para que recargar o volver
		// atrás no vuelva a anunciar un guardado que ya ocurrió.
		if ( window.history && window.history.replaceState ) {
			try {
				var limpia = new URL( window.location.href );
				limpia.searchParams.delete( 'settings-updated' );
				window.history.replaceState( null, '', limpia.toString() );
			} catch ( error ) {
				// URL no soportada: la limpieza es cosmética, se ignora.
			}
		}

		document.body.classList.add( 'ipw-modal-abierto' );

		// En el siguiente frame, para que la transición de entrada corra.
		window.requestAnimationFrame( function () {
			modal.classList.add( 'is-open' );

			if ( boton ) {
				boton.focus();
			}
		} );
	}

	function initCard( card ) {
		var empresa    = card.querySelector( '.ipw-empresa' );
		var area       = card.querySelector( '.ipw-area' );
		var trabajador = card.querySelector( '.ipw-trabajador' );
		var boton      = card.querySelector( '.ipw-probar' );
		var resultado  = card.querySelector( '.ipw-resultado' );

		if ( ! empresa || ! area || ! boton ) {
			return;
		}

		empresa.addEventListener( 'change', function () {
			resetSelect( trabajador, i18n.primero_area );
			ocultarResultado( resultado );

			if ( ! empresa.value ) {
				resetSelect( area, i18n.primero_empresa );
				return;
			}

			cargando( area );

			post( 'ipw_get_areas', { empresa_id: empresa.value } )
				.then( function ( data ) {
					llenarSelect( area, data.areas, i18n.elige_area, i18n.sin_areas, function ( item ) {
						return item.nombre + ' (' + item.con_test + ')';
					} );
				} )
				.catch( function ( mensaje ) {
					resetSelect( area, mensaje );
				} );
		} );

		area.addEventListener( 'change', function () {
			ocultarResultado( resultado );

			if ( ! trabajador ) {
				return;
			}

			if ( ! area.value ) {
				resetSelect( trabajador, i18n.primero_area );
				return;
			}

			cargando( trabajador );

			post( 'ipw_get_trabajadores', { empresa_id: empresa.value, area_id: area.value } )
				.then( function ( data ) {
					llenarSelect( trabajador, data.trabajadores, i18n.elige_trabajador, i18n.sin_trabajadores, function ( item ) {
						return item.nombre;
					} );
				} )
				.catch( function ( mensaje ) {
					resetSelect( trabajador, mensaje );
				} );
		} );

		boton.addEventListener( 'click', function () {
			var payload = {
				webhook:    card.dataset.webhook,
				empresa_id: empresa.value,
				area_id:    area.value,
			};

			if ( trabajador ) {
				payload.trabajador_id = trabajador.value;
			}

			boton.disabled    = true;
			boton.textContent = i18n.enviando || 'Enviando…';
			ocultarResultado( resultado );

			post( 'ipw_probar_envio', payload )
				.then( function ( data ) {
					pintarResultado( resultado, data );
				} )
				.catch( function ( mensaje ) {
					pintarResultado( resultado, { ok: false, status: 0, msg: mensaje } );
				} )
				.finally( function () {
					boton.disabled    = false;
					boton.textContent = i18n.probar || 'Probar envío';
				} );
		} );
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Selectores
	 * ─────────────────────────────────────────────────────────────────── */

	function resetSelect( select, textoPlaceholder ) {
		if ( ! select ) {
			return;
		}

		select.innerHTML = '';
		select.appendChild( opcion( '', textoPlaceholder || '—' ) );
		select.disabled  = true;
	}

	function cargando( select ) {
		select.innerHTML = '';
		select.appendChild( opcion( '', i18n.cargando || 'Cargando…' ) );
		select.disabled  = true;
	}

	/**
	 * @param {Array}    items       Filas devueltas por el servidor.
	 * @param {string}   placeholder Texto de la opción vacía cuando hay filas.
	 * @param {string}   vacio       Texto cuando el servidor no devolvió filas.
	 * @param {Function} etiqueta    Cómo se nombra cada fila.
	 */
	function llenarSelect( select, items, placeholder, vacio, etiqueta ) {
		select.innerHTML = '';

		if ( ! items || ! items.length ) {
			select.appendChild( opcion( '', vacio ) );
			select.disabled = true;
			return;
		}

		select.appendChild( opcion( '', placeholder ) );

		items.forEach( function ( item ) {
			select.appendChild( opcion( String( item.id ), etiqueta( item ) ) );
		} );

		select.disabled = false;
	}

	function opcion( value, texto ) {
		var option       = document.createElement( 'option' );
		option.value     = value;
		option.textContent = texto;
		return option;
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Resultado de la prueba
	 * ─────────────────────────────────────────────────────────────────── */

	function ocultarResultado( caja ) {
		if ( ! caja ) {
			return;
		}

		caja.hidden    = true;
		caja.innerHTML = '';
	}

	function pintarResultado( caja, data ) {
		if ( ! caja ) {
			return;
		}

		caja.className = 'ipw-resultado ' + ( data.ok ? 'is-ok' : 'is-error' );
		caja.innerHTML = '';

		var cabecera = document.createElement( 'div' );
		cabecera.className = 'ipw-resultado-cabecera';

		var badge = document.createElement( 'span' );
		badge.className   = 'ipw-badge';
		badge.textContent = data.status
			? ( i18n.http || 'HTTP' ) + ' ' + data.status
			: ( i18n.sin_conexion || 'sin respuesta' );
		cabecera.appendChild( badge );

		var mensaje = document.createElement( 'strong' );
		mensaje.textContent = data.msg || '';
		cabecera.appendChild( mensaje );

		if ( data.duracion_ms ) {
			var tiempo = document.createElement( 'span' );
			tiempo.className   = 'ipw-tiempo';
			tiempo.textContent = data.duracion_ms + ' ms';
			cabecera.appendChild( tiempo );
		}

		caja.appendChild( cabecera );

		if ( data.url ) {
			var destino = document.createElement( 'p' );
			destino.className = 'ipw-destino';
			destino.textContent = ( i18n.enviado_a || 'Enviado a' ) + ': ' + data.url;
			caja.appendChild( destino );
		}

		if ( typeof data.body !== 'undefined' ) {
			var titulo = document.createElement( 'p' );
			titulo.className   = 'ipw-resultado-titulo';
			titulo.textContent = i18n.respuesta || 'Respuesta del endpoint';
			caja.appendChild( titulo );

			var pre = document.createElement( 'pre' );
			// textContent, nunca innerHTML: el cuerpo viene de un sistema
			// externo y no debe interpretarse como HTML en wp-admin.
			pre.textContent = data.body || ( i18n.cuerpo_vacio || '(sin cuerpo)' );
			caja.appendChild( pre );
		}

		if ( data.pdf_url ) {
			var enlace   = document.createElement( 'a' );
			enlace.href  = data.pdf_url;
			enlace.target = '_blank';
			enlace.rel   = 'noopener noreferrer';
			enlace.className   = 'button ipw-abrir-pdf';
			enlace.textContent = i18n.abrir_pdf || 'Abrir el PDF generado';
			caja.appendChild( enlace );
		}

		caja.hidden = false;
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Transporte
	 * ─────────────────────────────────────────────────────────────────── */

	/**
	 * POST a admin-ajax.php. Resuelve con `data` en éxito y rechaza con el
	 * mensaje de error ya legible, para que quien llama no tenga que
	 * volver a distinguir entre error de red y error de aplicación.
	 */
	function post( action, payload ) {
		var body = new URLSearchParams(
			Object.assign( { action: action, nonce: window.ipwAdmin.nonce }, payload )
		);

		return fetch( window.ipwAdmin.url, {
			method:      'POST',
			credentials: 'same-origin',
			headers:     { 'Content-Type': 'application/x-www-form-urlencoded' },
			body:        body,
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( json ) {
				if ( ! json || ! json.success ) {
					throw new Error( ( json && json.data && json.data.msg ) || i18n.error_red );
				}

				return json.data;
			} )
			.catch( function ( error ) {
				throw ( error && error.message ) || i18n.error_red;
			} );
	}
} )();
