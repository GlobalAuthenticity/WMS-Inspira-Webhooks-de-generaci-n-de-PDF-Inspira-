# Webhooks de generación de PDF (Inspira)

Pantalla única en wp-admin (**Webhooks de PDF**) para configurar y probar las
URLs a las que Inspira envía los datos de un informe para que le devuelvan el
PDF. Sustituye las URLs que estaban escritas a mano en el tema hijo y en
*Áreas Asignadas*.

## Informes configurables

| Slug | Informe | Dónde se dispara | URL original |
|---|---|---|---|
| `personal` | Resultado personal completo | Botón «Descargar resultado» en `/resultado-test-personal-completo/` | `…/webhook/pdf_inspira` |
| `area` | Informe general (área y empresa) | Botones «Informe general» de `/mi-cuenta/areas/`: el de cada fila y el del menú «Acciones» | `…/webhook/pdf_aprobandome` |
| `usuario` | Informe individual (trabajador) | Botón «Ver resultados» de cada usuario en el panel de áreas | `…/webhook/pdf_aprobandome` |

Los dos botones de «Informe general» generan el mismo documento (uno de un
área, otro de todas las áreas de la empresa), así que comparten el webhook
`area` a propósito: cambiar esa URL afecta a los dos.

## Cómo llega la URL a cada botón

El plugin imprime en el `<head>` del front-end:

```js
window.ipwPdfWebhooks = { personal: "…", area: "…", usuario: "…" };
```

Los consumidores lo leen con respaldo en cascada, de forma que **desactivar
este plugin no rompe ninguna descarga**:

- `themes/astra-child/assets/js/download-results.js` → `ipwPdfWebhooks.personal`,
  y si no existe, el literal original.
- `plugins/areas-asignadas/assets/js/areas-asignadas.js` → `ipwPdfWebhooks[tipo]`,
  luego `apAjax.webhook_pdf` (el ajuste propio de ese plugin), y por último el
  literal original.

Mientras este plugin esté activo, `AP_Settings::get('webhook_pdf')` devuelve el
valor central, para que no existan dos valores distintos del mismo webhook. El
campo correspondiente en los ajustes de *Áreas Asignadas* se muestra
deshabilitado con un enlace a esta pantalla.

En PHP, la URL se resuelve con `ipw_get_webhook( $slug )`.

## Valores por defecto

Mientras nadie guarde nada, cada webhook usa la URL que estaba escrita en el
código, así que instalar el plugin no cambia el comportamiento. Vaciar un
campo y guardar restablece ese valor por defecto.

Solo se aceptan URLs `http`/`https` absolutas: una URL inválida no se guarda,
se conserva la anterior y se avisa en pantalla.

## Envío de prueba

Cada informe tiene su bloque «Enviar prueba» con selectores en cascada
(empresa → área → trabajador). Solo se listan áreas y trabajadores **con el
test ya respondido**, porque un envío contra alguien sin respuestas produciría
un PDF vacío y una falsa alarma sobre el webhook.

El payload se construye con las mismas funciones que usan los botones reales
(`get_results_user()` y `get_results_area()`, definidas en el tema hijo), así
que lo que se prueba es exactamente la estructura de datos de producción.

La petición sale **desde el servidor** (`wp_remote_post`), no desde el
navegador. Es deliberado: desde el navegador, una respuesta sin cabeceras CORS
se vería como un error de red genérico y sería imposible distinguir «el webhook
respondió 500» de «respondió bien pero el navegador no me deja leerlo», que es
justo lo que esta pantalla existe para diagnosticar.

El resultado muestra el código HTTP, la duración, el cuerpo devuelto (recortado
a 4 000 caracteres y renderizado como texto, nunca como HTML) y, si la respuesta
trae `pdfUrl`, un enlace para abrir el PDF generado.

La prueba usa la URL **guardada**, no la que haya sin guardar en el campo: se
comprueba lo que está en producción.

## Permisos

Configurar y probar requiere `manage_options`. Los tres endpoints AJAX
(`ipw_get_areas`, `ipw_get_trabajadores`, `ipw_probar_envio`) verifican esa
capacidad y un nonce antes de hacer nada.

## Dependencias

- Tabla `{prefix}areas` y `{prefix}user_members` (las crea *Áreas Asignadas*).
- `get_results_user()` y `get_results_area()` del tema hijo, solo para el envío
  de prueba. Si no existen, la pantalla lo dice en vez de enviar un payload
  inventado; guardar URLs sigue funcionando.
