<?php
/**
 * Pantalla «Webhooks de generación de PDF» en wp-admin.
 *
 * Un solo formulario con una tarjeta por informe: URL editable + envío de
 * prueba con selectores en cascada (empresa → área → trabajador). La
 * pantalla se genera recorriendo IPW_Settings::definitions(), así que un
 * informe nuevo aparece aquí sin tocar este archivo.
 *
 * @package InspiraPdfWebhooks
 */

defined( 'ABSPATH' ) || exit;

class IPW_Admin {

	public function register_hooks(): void {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'in_admin_header', [ $this, 'silenciar_avisos_ajenos' ], 99 );
	}

	/**
	 * Deja esta pantalla sin los avisos que otros plugins inyectan en
	 * todo wp-admin (peticiones de reseña, estado de Turnstile, avisos de
	 * actualización…). Aquí no aportan nada y empujan hacia abajo el
	 * único contenido que importa, que es el formulario.
	 *
	 * Se limpia solo en esta pantalla, comprobada con get_current_screen():
	 * esos avisos siguen apareciendo con normalidad en el resto del panel,
	 * que es donde su autor espera que se lean.
	 *
	 * Los mensajes propios del plugin no viajan por estos hooks: los
	 * imprime render_page() con settings_errors(), así que «Ajustes
	 * guardados» y los errores de URL inválida se siguen viendo.
	 */
	public function silenciar_avisos_ajenos(): void {
		$screen = get_current_screen();

		if ( ! $screen || 'toplevel_page_' . IPW_Settings::MENU_SLUG !== $screen->id ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		remove_all_actions( 'user_admin_notices' );
		remove_all_actions( 'network_admin_notices' );
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'Webhooks de generación de PDF', IPW_TEXT_DOMAIN ),
			__( 'Webhooks de PDF', IPW_TEXT_DOMAIN ),
			'manage_options',
			IPW_Settings::MENU_SLUG,
			[ $this, 'render_page' ],
			'dashicons-media-document',
			59
		);
	}

	public function enqueue_assets( string $hook ): void {
		if ( 'toplevel_page_' . IPW_Settings::MENU_SLUG !== $hook ) {
			return;
		}

		// Inter, la tipografía de aprobandome.com. Se carga solo en esta
		// pantalla para no alterar el resto de wp-admin.
		wp_enqueue_style(
			'ipw-inter',
			'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
			[],
			IPW_VERSION
		);

		wp_enqueue_style(
			'ipw-admin',
			IPW_PLUGIN_URL . 'assets/admin.css',
			[ 'ipw-inter' ],
			IPW_VERSION
		);

		wp_enqueue_script(
			'ipw-admin',
			IPW_PLUGIN_URL . 'assets/admin.js',
			[],
			IPW_VERSION,
			true
		);

		wp_localize_script( 'ipw-admin', 'ipwAdmin', [
			'url'   => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( IPW_Tester::NONCE_ACTION ),
			'i18n'  => [
				'elige_empresa'     => __( '— Elige una empresa —', IPW_TEXT_DOMAIN ),
				'elige_area'        => __( '— Elige un área —', IPW_TEXT_DOMAIN ),
				'primero_empresa'   => __( '— Elige primero una empresa —', IPW_TEXT_DOMAIN ),
				'primero_area'      => __( '— Elige primero un área —', IPW_TEXT_DOMAIN ),
				'elige_trabajador'  => __( '— Elige un trabajador —', IPW_TEXT_DOMAIN ),
				'cargando'          => __( 'Cargando…', IPW_TEXT_DOMAIN ),
				'sin_areas'         => __( '— Esta empresa no tiene áreas con test respondido —', IPW_TEXT_DOMAIN ),
				'sin_trabajadores'  => __( '— Nadie de esta área respondió el test —', IPW_TEXT_DOMAIN ),
				'enviando'          => __( 'Enviando…', IPW_TEXT_DOMAIN ),
				'probar'            => __( 'Probar envío', IPW_TEXT_DOMAIN ),
				'error_red'         => __( 'No se pudo completar la petición desde el navegador.', IPW_TEXT_DOMAIN ),
				'http'              => __( 'HTTP', IPW_TEXT_DOMAIN ),
				'sin_conexion'      => __( 'sin respuesta', IPW_TEXT_DOMAIN ),
				'respuesta'         => __( 'Respuesta del endpoint', IPW_TEXT_DOMAIN ),
				'cuerpo_vacio'      => __( '(el endpoint no devolvió cuerpo)', IPW_TEXT_DOMAIN ),
				'abrir_pdf'         => __( 'Abrir el PDF generado', IPW_TEXT_DOMAIN ),
				'enviado_a'         => __( 'Enviado a', IPW_TEXT_DOMAIN ),
			],
		] );
	}

	public function render_page(): void {
		// Segunda comprobación, además de la capacidad del menú: render_page()
		// es público y podría alcanzarse por otra vía.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos para ver esta pantalla.', IPW_TEXT_DOMAIN ) );
		}

		$definitions = IPW_Settings::definitions();
		$empresas    = IPW_Data::empresas();
		?>
		<div class="wrap ipw-wrap">

			<div class="ipw-hero">
				<div class="ipw-hero-icono" aria-hidden="true">
					<span class="dashicons dashicons-media-document"></span>
				</div>
				<div>
					<h1><?php esc_html_e( 'Webhooks de generación de PDF', IPW_TEXT_DOMAIN ); ?></h1>
					<p><?php esc_html_e( 'URLs a las que se envían los informes para generar el PDF. Al guardar, los botones usan la nueva URL de inmediato.', IPW_TEXT_DOMAIN ); ?></p>
				</div>
			</div>

			<?php
			/*
			 * Marca dónde debe colocar WordPress los avisos. Sin ella,
			 * common.js los inserta justo detrás del primer <h1>, que aquí
			 * vive dentro de la cabecera morada, y el aviso aparecía
			 * incrustado dentro de ella.
			 */
			?>
			<div class="wp-header-end"></div>

			<?php
			/*
			 * El éxito se confirma con un modal (render_modal_exito) y no
			 * con un aviso en línea. Los errores sí se quedan como aviso
			 * fijo: hay que poder leerlos mientras se corrige el campo que
			 * los provocó, y un modal obliga a cerrarlos para hacerlo.
			 *
			 * Los dos casos son excluyentes: si algún campo falló no se
			 * anuncia un guardado correcto.
			 */
			$errores_guardado = get_settings_errors( IPW_Settings::OPTION_KEY );

			if ( ! empty( $errores_guardado ) ) {
				settings_errors( IPW_Settings::OPTION_KEY );
			}
			?>

			<form method="post" action="options.php">
				<?php settings_fields( IPW_Settings::MENU_SLUG ); ?>

				<?php foreach ( $definitions as $slug => $definicion ) : ?>
					<?php $this->render_card( $slug, $definicion, $empresas ); ?>
				<?php endforeach; ?>

				<?php submit_button( __( 'Guardar cambios', IPW_TEXT_DOMAIN ) ); ?>
			</form>

			<?php $this->render_modal_exito( empty( $errores_guardado ) ); ?>
		</div>
		<?php
	}

	/**
	 * Modal de confirmación tras guardar.
	 *
	 * Se imprime solo cuando la vuelta de options.php trae
	 * `settings-updated` y ningún campo dio error. El marcado sale ya
	 * hecho desde PHP en vez de construirlo en JavaScript para que el
	 * texto pase por el sistema de traducción como el resto de la
	 * pantalla; admin.js se limita a abrirlo y cerrarlo.
	 *
	 * @param bool $sin_errores Si el guardado terminó sin errores propios.
	 */
	private function render_modal_exito( bool $sin_errores ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo decide si se muestra un mensaje; options.php ya validó el nonce del guardado.
		if ( ! $sin_errores || ! isset( $_GET['settings-updated'] ) ) {
			return;
		}
		?>
		<div class="ipw-modal" id="ipw-modal-exito" role="dialog" aria-modal="true" aria-labelledby="ipw-modal-titulo">
			<div class="ipw-modal-caja" role="document">
				<div class="ipw-modal-icono" aria-hidden="true">
					<span class="dashicons dashicons-yes"></span>
				</div>
				<h2 id="ipw-modal-titulo"><?php esc_html_e( 'Cambios guardados', IPW_TEXT_DOMAIN ); ?></h2>
				<p><?php esc_html_e( 'Los botones de descarga ya usan las URLs nuevas. No hace falta tocar ningún archivo.', IPW_TEXT_DOMAIN ); ?></p>
				<button type="button" class="button button-primary ipw-modal-cerrar">
					<?php esc_html_e( 'Entendido', IPW_TEXT_DOMAIN ); ?>
				</button>
			</div>
		</div>
		<?php
	}

	/**
	 * @param array<string,string>                      $definicion
	 * @param array<int,array{id:int,nombre:string}>    $empresas
	 */
	private function render_card( string $slug, array $definicion, array $empresas ): void {
		$field_id     = 'ipw-url-' . $slug;
		$necesita_usr = 'worker' === $definicion['subject'];
		?>
		<div class="ipw-card" data-webhook="<?php echo esc_attr( $slug ); ?>" data-needs-worker="<?php echo $necesita_usr ? '1' : '0'; ?>">

			<h2><?php echo esc_html( $definicion['label'] ); ?></h2>
			<p class="ipw-context">
				<?php echo esc_html( $definicion['context'] ); ?>
				<?php if ( '' !== $definicion['desc'] ) : ?>
					<span class="ipw-chip"><?php echo esc_html( $definicion['desc'] ); ?></span>
				<?php endif; ?>
			</p>

			<div class="ipw-field">
				<label for="<?php echo esc_attr( $field_id ); ?>"><?php esc_html_e( 'URL del webhook', IPW_TEXT_DOMAIN ); ?></label>
				<input
					type="url"
					id="<?php echo esc_attr( $field_id ); ?>"
					name="<?php echo esc_attr( IPW_Settings::OPTION_KEY ); ?>[<?php echo esc_attr( $slug ); ?>]"
					value="<?php echo esc_attr( IPW_Settings::get_url( $slug ) ); ?>"
					class="ipw-url-input code"
					inputmode="url"
					spellcheck="false"
					placeholder="https://"
				>
				<?php if ( IPW_Settings::is_customized( $slug ) ) : ?>
					<p class="ipw-hint">
						<?php esc_html_e( 'Original:', IPW_TEXT_DOMAIN ); ?>
						<code><?php echo esc_html( IPW_Settings::get_default( $slug ) ); ?></code>
					</p>
				<?php endif; ?>
			</div>

			<div class="ipw-test">
				<h3><?php esc_html_e( 'Enviar prueba', IPW_TEXT_DOMAIN ); ?></h3>

				<?php if ( empty( $empresas ) ) : ?>
					<p class="ipw-hint">
						<?php esc_html_e( 'No hay ninguna empresa con tests respondidos, así que todavía no hay datos reales que enviar.', IPW_TEXT_DOMAIN ); ?>
					</p>
				<?php else : ?>

				<div class="ipw-selects">
					<div class="ipw-select">
						<label for="ipw-empresa-<?php echo esc_attr( $slug ); ?>"><?php esc_html_e( 'Empresa', IPW_TEXT_DOMAIN ); ?></label>
						<select id="ipw-empresa-<?php echo esc_attr( $slug ); ?>" class="ipw-empresa">
							<option value=""><?php esc_html_e( '— Elige una empresa —', IPW_TEXT_DOMAIN ); ?></option>
							<?php foreach ( $empresas as $empresa ) : ?>
								<option value="<?php echo esc_attr( (string) $empresa['id'] ); ?>"><?php echo esc_html( $empresa['nombre'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="ipw-select">
						<label for="ipw-area-<?php echo esc_attr( $slug ); ?>"><?php esc_html_e( 'Área', IPW_TEXT_DOMAIN ); ?></label>
						<select id="ipw-area-<?php echo esc_attr( $slug ); ?>" class="ipw-area" disabled>
							<option value=""><?php esc_html_e( '— Elige primero una empresa —', IPW_TEXT_DOMAIN ); ?></option>
						</select>
					</div>

					<?php if ( $necesita_usr ) : ?>
						<div class="ipw-select">
							<label for="ipw-trabajador-<?php echo esc_attr( $slug ); ?>"><?php esc_html_e( 'Trabajador', IPW_TEXT_DOMAIN ); ?></label>
							<select id="ipw-trabajador-<?php echo esc_attr( $slug ); ?>" class="ipw-trabajador" disabled>
								<option value=""><?php esc_html_e( '— Elige primero un área —', IPW_TEXT_DOMAIN ); ?></option>
							</select>
						</div>
					<?php endif; ?>
				</div>

				<p class="ipw-hint">
					<?php esc_html_e( 'Solo aparece quien ya respondió el test. Se envía la URL guardada, no la que haya sin guardar.', IPW_TEXT_DOMAIN ); ?>
				</p>

				<p class="ipw-acciones">
					<button type="button" class="button ipw-probar"><?php esc_html_e( 'Probar envío', IPW_TEXT_DOMAIN ); ?></button>
				</p>

				<div class="ipw-resultado" hidden></div>

				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
