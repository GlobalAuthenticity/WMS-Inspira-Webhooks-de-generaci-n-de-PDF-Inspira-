<?php
/**
 * Registro de webhooks de PDF y su almacenamiento.
 *
 * Toda la pantalla de administración y el envío de prueba se generan a
 * partir de self::definitions(): añadir un informe nuevo es añadir una
 * entrada ahí, no tocar el formulario ni el tester.
 *
 * @package InspiraPdfWebhooks
 */

defined( 'ABSPATH' ) || exit;

class IPW_Settings {

	const OPTION_KEY = 'ipw_webhooks';
	const MENU_SLUG  = 'ipw-pdf-webhooks';

	/**
	 * Cada webhook configurable, con la URL que el código usaba antes de
	 * existir esta pantalla. Ese valor por defecto es lo que mantiene las
	 * descargas operativas desde el minuto cero: mientras nadie guarde
	 * nada, el comportamiento es idéntico al anterior.
	 *
	 * - `subject` es lo que hay que elegir en el envío de prueba para
	 *   construir un payload real: 'worker' (un trabajador con test
	 *   respondido) o 'area' (un área con al menos un test respondido).
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function definitions(): array {
		return [
			'personal' => [
				'label'    => __( 'Resultado personal completo', IPW_TEXT_DOMAIN ),
				'context'  => __( 'Botón «Descargar resultado» en /resultado-test-personal-completo/', IPW_TEXT_DOMAIN ),
				'desc'     => '',
				'default'  => 'https://api.efrenmartinezortiz-ia.com/webhook/pdf_inspira',
				'subject'  => 'worker',
			],
			'area' => [
				'label'    => __( 'Informe general (área y empresa)', IPW_TEXT_DOMAIN ),
				'context'  => __( 'Botones «Informe general» en /mi-cuenta/areas/: el de cada fila y el del menú «Acciones»', IPW_TEXT_DOMAIN ),
				// El único dato que no se deduce mirando la pantalla: que
				// esta URL gobierna dos botones distintos a la vez.
				'desc'     => __( 'Ambos botones comparten este webhook.', IPW_TEXT_DOMAIN ),
				'default'  => 'https://api.efrenmartinezortiz-ia.com/webhook/pdf_aprobandome',
				'subject'  => 'area',
			],
			'usuario' => [
				'label'    => __( 'Informe individual (trabajador)', IPW_TEXT_DOMAIN ),
				'context'  => __( 'Botón «Ver resultados» de cada usuario en el panel de áreas', IPW_TEXT_DOMAIN ),
				'desc'     => '',
				'default'  => 'https://api.efrenmartinezortiz-ia.com/webhook/pdf_aprobandome',
				'subject'  => 'worker',
			],
		];
	}

	public function register_hooks(): void {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function register_settings(): void {
		register_setting( self::MENU_SLUG, self::OPTION_KEY, [
			'type'              => 'array',
			'sanitize_callback' => [ $this, 'sanitize' ],
			'default'           => [],
		] );
	}

	/**
	 * URL efectiva de un webhook: lo guardado, o el valor con el que
	 * operaba el código antes de esta pantalla.
	 */
	public static function get_url( string $slug ): string {
		$definitions = self::definitions();

		if ( ! isset( $definitions[ $slug ] ) ) {
			return '';
		}

		$guardado = get_option( self::OPTION_KEY, [] );

		if ( is_array( $guardado ) && ! empty( $guardado[ $slug ] ) ) {
			return (string) $guardado[ $slug ];
		}

		return $definitions[ $slug ]['default'];
	}

	/**
	 * Valor por defecto (el que estaba escrito en el código), para poder
	 * mostrarlo en la pantalla como referencia de a dónde volver.
	 */
	public static function get_default( string $slug ): string {
		return self::definitions()[ $slug ]['default'] ?? '';
	}

	/** ¿Esta URL viene de la opción guardada o sigue siendo la del código? */
	public static function is_customized( string $slug ): bool {
		$guardado = get_option( self::OPTION_KEY, [] );

		return is_array( $guardado ) && ! empty( $guardado[ $slug ] );
	}

	/**
	 * Mapa slug => URL, tal y como lo consume el JavaScript del front-end.
	 *
	 * @return array<string,string>
	 */
	public static function all_urls(): array {
		$urls = [];

		foreach ( array_keys( self::definitions() ) as $slug ) {
			$urls[ $slug ] = self::get_url( $slug );
		}

		return $urls;
	}

	/**
	 * Solo se guardan URLs http(s) absolutas. Una URL inválida no se
	 * escribe: se conserva la anterior y se avisa, porque guardar una
	 * cadena rota dejaría el botón de descarga fallando en producción sin
	 * que nadie lo notara hasta que un usuario lo pulsara.
	 *
	 * Un campo vacío sí es válido y significa «vuelve al valor por
	 * defecto», que es la forma de deshacer un cambio.
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,string>
	 */
	public function sanitize( $input ): array {
		$input       = is_array( $input ) ? $input : [];
		$definitions = self::definitions();
		$limpio      = [];

		foreach ( $definitions as $slug => $definicion ) {
			$valor = trim( (string) ( $input[ $slug ] ?? '' ) );

			if ( '' === $valor ) {
				// Vacío = restablecer el valor por defecto del código.
				continue;
			}

			$url = esc_url_raw( $valor, [ 'http', 'https' ] );

			if ( '' === $url || ! wp_http_validate_url( $url ) ) {
				add_settings_error(
					self::OPTION_KEY,
					'ipw_url_invalida_' . $slug,
					sprintf(
						/* translators: %s: nombre del informe */
						__( '«%s»: la URL introducida no es una dirección http(s) válida. Se conservó la URL anterior.', IPW_TEXT_DOMAIN ),
						$definicion['label']
					),
					'error'
				);

				if ( self::is_customized( $slug ) ) {
					$limpio[ $slug ] = self::get_url( $slug );
				}

				continue;
			}

			$limpio[ $slug ] = $url;
		}

		return $limpio;
	}
}
