<?php
/**
 * Consultas que alimentan los selectores del envío de prueba.
 *
 * Toda la SQL del plugin vive aquí. Se lee de las mismas tablas que usa
 * «Áreas Asignadas» ({prefix}areas y {prefix}user_members) pero sin
 * depender de ese plugin: si no estuviera instalado, esta pantalla
 * simplemente no encontraría empresas y lo diría, en vez de romperse.
 *
 * Se listan únicamente áreas y trabajadores CON test respondido
 * (usermeta `question_test_ids` no vacío). Un envío de prueba contra
 * alguien que no ha respondido produciría un PDF vacío y una falsa
 * alarma sobre el webhook.
 *
 * @package InspiraPdfWebhooks
 */

defined( 'ABSPATH' ) || exit;

class IPW_Data {

	const TEST_META_KEY = 'question_test_ids';

	/**
	 * Condición que define «este usuario respondió el test», usada igual
	 * en las tres consultas para que empresa, área y trabajador filtren
	 * por el mismo criterio y no puedan contradecirse.
	 *
	 * No basta con que exista la fila de usermeta. save_test_answers()
	 * guarda `$_POST['answers']` tal cual, así que una sesión de test
	 * abandonada o interrumpida puede dejar la meta creada pero con un
	 * JSON vacío. Esas filas se descartan aquí: contarlas metería en los
	 * selectores a gente cuyo informe saldría en blanco, que es justo lo
	 * que este filtro existe para evitar.
	 */
	const TEST_RESPONDIDO_SQL = "meta.meta_value <> '' AND meta.meta_value NOT IN ( '[]', 'null', '\"\"', '{}' )";

	/**
	 * Rol que identifica a una empresa. Se reutiliza el ajuste de «Áreas
	 * Asignadas» si existe, para que ambas pantallas hablen del mismo
	 * conjunto de usuarios aunque el rol se haya renombrado.
	 */
	public static function rol_empresa(): string {
		$ajustes = get_option( 'ap_ajustes', [] );

		if ( is_array( $ajustes ) && ! empty( $ajustes['rol_empresa_admin'] ) ) {
			return (string) $ajustes['rol_empresa_admin'];
		}

		return 'empresa_admin';
	}

	/**
	 * Empresas que tienen al menos un área con resultados. Filtrar aquí
	 * evita que el administrador elija una empresa y se encuentre con los
	 * dos selectores siguientes vacíos sin explicación.
	 *
	 * @return array<int,array{id:int,nombre:string}>
	 */
	public static function empresas(): array {
		global $wpdb;

		$grupo_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT a.grupo_id
			 FROM {$wpdb->prefix}areas a
			 INNER JOIN {$wpdb->prefix}user_members um ON um.area_id = a.id
			 INNER JOIN {$wpdb->usermeta} meta
			         ON meta.user_id = um.user_id
			        AND meta.meta_key = %s
			        AND " . self::TEST_RESPONDIDO_SQL . "
			 WHERE a.grupo_id > 0",
			self::TEST_META_KEY
		) );

		if ( empty( $grupo_ids ) ) {
			return [];
		}

		$empresas = [];

		foreach ( array_map( 'intval', $grupo_ids ) as $grupo_id ) {
			$usuario = get_userdata( $grupo_id );

			if ( ! $usuario ) {
				// Empresa borrada que dejó áreas huérfanas: no se ofrece.
				continue;
			}

			$empresas[] = [
				'id'     => $grupo_id,
				'nombre' => self::nombre_usuario( $usuario ),
			];
		}

		usort( $empresas, static function ( $a, $b ) {
			return strcasecmp( $a['nombre'], $b['nombre'] );
		} );

		return $empresas;
	}

	/**
	 * Áreas de una empresa que ya tienen al menos un test respondido.
	 *
	 * @return array<int,array{id:int,nombre:string,con_test:int}>
	 */
	public static function areas( int $grupo_id ): array {
		global $wpdb;

		$filas = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.id, a.nombre,
			        COUNT(DISTINCT um.user_id) AS con_test
			 FROM {$wpdb->prefix}areas a
			 INNER JOIN {$wpdb->prefix}user_members um ON um.area_id = a.id
			 INNER JOIN {$wpdb->usermeta} meta
			         ON meta.user_id = um.user_id
			        AND meta.meta_key = %s
			        AND " . self::TEST_RESPONDIDO_SQL . "
			 WHERE a.grupo_id = %d
			 GROUP BY a.id, a.nombre
			 ORDER BY a.nombre ASC",
			self::TEST_META_KEY,
			$grupo_id
		), ARRAY_A );

		return array_map( static function ( array $fila ): array {
			return [
				'id'       => (int) $fila['id'],
				'nombre'   => (string) $fila['nombre'],
				'con_test' => (int) $fila['con_test'],
			];
		}, (array) $filas );
	}

	/**
	 * Trabajadores de un área que ya respondieron el test.
	 *
	 * @return array<int,array{id:int,nombre:string}>
	 */
	public static function trabajadores( int $area_id ): array {
		global $wpdb;

		$user_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT um.user_id
			 FROM {$wpdb->prefix}user_members um
			 INNER JOIN {$wpdb->usermeta} meta
			         ON meta.user_id = um.user_id
			        AND meta.meta_key = %s
			        AND " . self::TEST_RESPONDIDO_SQL . "
			 WHERE um.area_id = %d",
			self::TEST_META_KEY,
			$area_id
		) );

		$trabajadores = [];

		foreach ( array_map( 'intval', (array) $user_ids ) as $user_id ) {
			$usuario = get_userdata( $user_id );

			if ( ! $usuario ) {
				continue;
			}

			$trabajadores[] = [
				'id'     => $user_id,
				'nombre' => self::nombre_usuario( $usuario ),
			];
		}

		usort( $trabajadores, static function ( $a, $b ) {
			return strcasecmp( $a['nombre'], $b['nombre'] );
		} );

		return $trabajadores;
	}

	/** ¿El área indicada pertenece a esa empresa? */
	public static function area_es_de_empresa( int $area_id, int $grupo_id ): bool {
		global $wpdb;

		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}areas WHERE id = %d AND grupo_id = %d",
			$area_id,
			$grupo_id
		) );
	}

	/** ¿El trabajador indicado está inscrito en esa área? */
	public static function trabajador_es_de_area( int $user_id, int $area_id ): bool {
		global $wpdb;

		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}user_members WHERE user_id = %d AND area_id = %d LIMIT 1",
			$user_id,
			$area_id
		) );
	}

	/**
	 * Nombre presentable: nombre y apellidos si los hay, si no el
	 * display_name, y en último caso el correo.
	 */
	private static function nombre_usuario( WP_User $usuario ): string {
		$nombre = trim(
			get_user_meta( $usuario->ID, 'first_name', true ) . ' ' .
			get_user_meta( $usuario->ID, 'last_name', true )
		);

		if ( '' === $nombre ) {
			$nombre = $usuario->display_name;
		}

		if ( '' === trim( (string) $nombre ) ) {
			return $usuario->user_email;
		}

		return sprintf( '%s (%s)', $nombre, $usuario->user_email );
	}
}
