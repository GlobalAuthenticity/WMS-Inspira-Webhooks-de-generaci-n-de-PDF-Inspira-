<?php
/**
 * Envío de prueba: construye el MISMO payload que envía el botón real y
 * lo manda al webhook configurado, informando del código HTTP y de la
 * respuesta tal cual llegó.
 *
 * El envío se hace desde el servidor (wp_remote_post) y no desde el
 * navegador como hacen los botones reales. Es deliberado: desde el
 * navegador una respuesta sin cabeceras CORS se vería como un error de
 * red genérico y sería imposible distinguir «el webhook respondió 500» de
 * «el webhook respondió bien pero el navegador no me deja leerlo», que es
 * justo lo que esta pantalla existe para diagnosticar.
 *
 * @package InspiraPdfWebhooks
 */

defined( 'ABSPATH' ) || exit;

class IPW_Tester {

	const NONCE_ACTION = 'ipw_test';
	const TIMEOUT      = 45;

	/** Tope de caracteres de respuesta que se devuelven a la pantalla. */
	const MAX_BODY = 4000;

	public function register_hooks(): void {
		add_action( 'wp_ajax_ipw_get_areas', [ $this, 'ajax_get_areas' ] );
		add_action( 'wp_ajax_ipw_get_trabajadores', [ $this, 'ajax_get_trabajadores' ] );
		add_action( 'wp_ajax_ipw_probar_envio', [ $this, 'ajax_probar_envio' ] );
	}

	/**
	 * Puerta única de los tres endpoints: sin `manage_options` no se
	 * listan empresas ni se dispara ningún envío. El nonce cubre además
	 * el CSRF, porque un envío de prueba llama a un sistema externo.
	 */
	private function autorizar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'msg' => __( 'No tienes permisos para esta acción.', IPW_TEXT_DOMAIN ) ], 403 );
		}

		if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
			wp_send_json_error( [ 'msg' => __( 'La sesión caducó. Recarga la página e inténtalo de nuevo.', IPW_TEXT_DOMAIN ) ], 403 );
		}
	}

	public function ajax_get_areas(): void {
		$this->autorizar();

		$grupo_id = (int) ( $_POST['empresa_id'] ?? 0 );

		if ( ! $grupo_id ) {
			wp_send_json_error( [ 'msg' => __( 'Empresa inválida.', IPW_TEXT_DOMAIN ) ], 400 );
		}

		wp_send_json_success( [ 'areas' => IPW_Data::areas( $grupo_id ) ] );
	}

	public function ajax_get_trabajadores(): void {
		$this->autorizar();

		$grupo_id = (int) ( $_POST['empresa_id'] ?? 0 );
		$area_id  = (int) ( $_POST['area_id'] ?? 0 );

		if ( ! $grupo_id || ! $area_id ) {
			wp_send_json_error( [ 'msg' => __( 'Área inválida.', IPW_TEXT_DOMAIN ) ], 400 );
		}

		if ( ! IPW_Data::area_es_de_empresa( $area_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Esa área no pertenece a la empresa seleccionada.', IPW_TEXT_DOMAIN ) ], 400 );
		}

		wp_send_json_success( [ 'trabajadores' => IPW_Data::trabajadores( $area_id ) ] );
	}

	/**
	 * Construye el payload real del informe elegido y lo envía al webhook
	 * que hay configurado en ese momento (no al que pudiera haber escrito
	 * sin guardar en el formulario: se prueba lo que está en producción).
	 */
	public function ajax_probar_envio(): void {
		$this->autorizar();

		$slug        = sanitize_key( $_POST['webhook'] ?? '' );
		$definitions = IPW_Settings::definitions();

		if ( ! isset( $definitions[ $slug ] ) ) {
			wp_send_json_error( [ 'msg' => __( 'Informe desconocido.', IPW_TEXT_DOMAIN ) ], 400 );
		}

		$url = IPW_Settings::get_url( $slug );

		if ( ! $url || ! wp_http_validate_url( $url ) ) {
			wp_send_json_error( [ 'msg' => __( 'Este informe no tiene una URL válida guardada. Guarda una URL antes de probar.', IPW_TEXT_DOMAIN ) ], 400 );
		}

		$payload = $this->construir_payload( $definitions[ $slug ]['subject'] );

		if ( is_wp_error( $payload ) ) {
			wp_send_json_error( [ 'msg' => $payload->get_error_message() ], 400 );
		}

		$inicio = microtime( true );

		$respuesta = wp_remote_post( $url, [
			'timeout' => self::TIMEOUT,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( $payload ),
		] );

		$duracion_ms = (int) round( ( microtime( true ) - $inicio ) * 1000 );

		if ( is_wp_error( $respuesta ) ) {
			wp_send_json_success( [
				'ok'          => false,
				'url'         => $url,
				'status'      => 0,
				'duracion_ms' => $duracion_ms,
				'body'        => '',
				'pdf_url'     => '',
				'msg'         => sprintf(
					/* translators: %s: mensaje de error de la petición */
					__( 'No se pudo contactar con el webhook: %s', IPW_TEXT_DOMAIN ),
					$respuesta->get_error_message()
				),
			] );
		}

		$status = (int) wp_remote_retrieve_response_code( $respuesta );
		$body   = (string) wp_remote_retrieve_body( $respuesta );
		$ok     = $status >= 200 && $status < 300;

		wp_send_json_success( [
			'ok'          => $ok,
			'url'         => $url,
			'status'      => $status,
			'duracion_ms' => $duracion_ms,
			'body'        => $this->recortar( $body ),
			'pdf_url'     => $this->extraer_pdf_url( $body ),
			'msg'         => $ok
				? __( 'El webhook respondió correctamente.', IPW_TEXT_DOMAIN )
				: sprintf(
					/* translators: %d: código HTTP devuelto */
					__( 'El webhook respondió con un código de error (HTTP %d).', IPW_TEXT_DOMAIN ),
					$status
				),
		] );
	}

	/**
	 * Reproduce exactamente la forma de los datos que envía cada botón:
	 *
	 * - 'worker' → get_results_user(), que es lo que el navegador guarda en
	 *   localStorage['resultado'] (informe personal) y lo que devuelve el
	 *   AJAX ap_get_resultados_pdf (informe individual del panel).
	 * - 'area'   → get_results_area(), lo que devuelve ap_get_resultados_area_pdf.
	 *
	 * Ambas funciones las define el tema hijo (inc/helpers.php); si el tema
	 * activo no las trae, se avisa en vez de mandar un payload inventado
	 * que daría un falso negativo sobre el webhook.
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	private function construir_payload( string $subject ) {
		$grupo_id = (int) ( $_POST['empresa_id'] ?? 0 );
		$area_id  = (int) ( $_POST['area_id'] ?? 0 );
		$user_id  = (int) ( $_POST['trabajador_id'] ?? 0 );

		if ( ! $grupo_id || ! $area_id ) {
			return new WP_Error( 'ipw_seleccion', __( 'Elige una empresa y un área para la prueba.', IPW_TEXT_DOMAIN ) );
		}

		if ( ! IPW_Data::area_es_de_empresa( $area_id, $grupo_id ) ) {
			return new WP_Error( 'ipw_area', __( 'Esa área no pertenece a la empresa seleccionada.', IPW_TEXT_DOMAIN ) );
		}

		if ( 'area' === $subject ) {
			if ( ! function_exists( 'get_results_area' ) ) {
				return new WP_Error( 'ipw_helper', __( 'No se encontró get_results_area(): el tema hijo que la define no está activo.', IPW_TEXT_DOMAIN ) );
			}

			$resultado = get_results_area( $area_id );

			if ( empty( $resultado ) ) {
				return new WP_Error( 'ipw_sin_datos', __( 'Esa área no devolvió resultados.', IPW_TEXT_DOMAIN ) );
			}

			return $resultado;
		}

		if ( ! $user_id ) {
			return new WP_Error( 'ipw_seleccion', __( 'Elige un trabajador para la prueba.', IPW_TEXT_DOMAIN ) );
		}

		if ( ! IPW_Data::trabajador_es_de_area( $user_id, $area_id ) ) {
			return new WP_Error( 'ipw_trabajador', __( 'Ese trabajador no pertenece al área seleccionada.', IPW_TEXT_DOMAIN ) );
		}

		if ( ! function_exists( 'get_results_user' ) ) {
			return new WP_Error( 'ipw_helper', __( 'No se encontró get_results_user(): el tema hijo que la define no está activo.', IPW_TEXT_DOMAIN ) );
		}

		$resultado = get_results_user( $user_id );

		if ( empty( $resultado ) ) {
			return new WP_Error( 'ipw_sin_datos', __( 'Ese trabajador no devolvió resultados.', IPW_TEXT_DOMAIN ) );
		}

		return $resultado;
	}

	/**
	 * Si la respuesta trae `pdfUrl` (la clave que leen los botones reales
	 * para disparar la descarga), se extrae para poder abrir el PDF desde
	 * la propia pantalla y comprobar que el contenido es el esperado, no
	 * solo que el webhook devolvió 200.
	 */
	private function extraer_pdf_url( string $body ): string {
		$json = json_decode( $body, true );

		if ( ! is_array( $json ) || empty( $json['pdfUrl'] ) ) {
			return '';
		}

		$url = esc_url_raw( (string) $json['pdfUrl'], [ 'http', 'https' ] );

		return $url ? $url : '';
	}

	private function recortar( string $body ): string {
		if ( strlen( $body ) <= self::MAX_BODY ) {
			return $body;
		}

		return substr( $body, 0, self::MAX_BODY ) . "\n… (respuesta recortada)";
	}
}
